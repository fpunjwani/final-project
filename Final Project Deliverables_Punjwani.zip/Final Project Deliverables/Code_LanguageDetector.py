from __future__ import with_statement
from langdetect import detect
import csv


LanguageFinal={}
lines=[]

with open('twitterdata_cleanedtweet.csv', "rU") as f:
    for text in f.readlines():
        lines.append(text)

for text in lines[0:5]:
    language=detect(text)
    LanguageFinal[text]=language

with open('twitterdata_languagedetect.csv', 'wb') as csv_file:
    writer = csv.writer(csv_file)
    for key, value in LanguageFinal.items():
       writer.writerow([key, value])