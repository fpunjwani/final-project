from __future__ import with_statement
from google.cloud import language
import csv

language_client = language.Client()

#Dictionary of {tweettext:[sentiment.score, sentiment.magnitude]}
Sentimental={}

#initiate a new list that will contain all tweets
lines=[]

with open('twitterdata_cleanedtweet.txt', "rU") as f:
    for text in f.readlines():
        lines.append(text)

#read each element in lines list. Helps with debugging for language
#Google Sentiment Analysis can only read en and es. Languages like fr, de, pt aren't recognized and throw erros
#parsing through an iterable like the lines list allows to find the specific tweets that are in a different language and throwing errors
for text in lines:
    document = language_client.document_from_text(text)
    sentiment = document.analyze_sentiment().sentiment
    Senti=[sentiment.score, sentiment.magnitude]
    Sentimental[text]= Senti

#write a new file with all the scores
with open('twitterdata_scores.csv', 'wb') as csv_file:
    writer = csv.writer(csv_file)
    for key, value in Sentimental.items():
       writer.writerow([key, value])