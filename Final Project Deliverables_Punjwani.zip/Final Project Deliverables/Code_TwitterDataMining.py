import tweepy
from tweepy import Stream
from tweepy import OAuthHandler
from tweepy.api import API
from tweepy.streaming import StreamListener
import json
import datetime
import csv
import HTMLParser
import itertools
import preprocessor as p
 
#twitter API
consumer_key = '3wNmLBPj2LJFRqUiXRB49L3j7'
consumer_secret = 'HBCnGeEFGzGomZtuUtkP26buDhuuuacH1uFH6lAxS7LphC92g8'
access_token = '44210574-f3EOBWKOR2MM0hnGoz6hZ5zOXaNpb8Txyyhaf1tiR'
access_secret = 'OtAUPbjycsson4C2BNTxpY3ZQDxZfgL98fNsweLnmV2uu'
 
auth = OAuthHandler(consumer_key, consumer_secret)
auth.set_access_token(access_token, access_secret)

#geocode of the different cities
boston = '42.3601,-71.0589,40mi'
newyork = '40.7453,-73.9922,30mi'
houston = '30.02202,-95.68494,100mi'

api = API(auth_handler=auth)
 
#kwargs takes in one geocode at a time
kwargs = {
    'q': '*',
    'geocode': newyork
}

#clean tweet for special characters
def unicodetoascii(text):
    
    uni2ascii = {
            ord('\xe2\x80\x99'.decode('utf-8')): ord("'"),
            ord('\xe2\x80\x9c'.decode('utf-8')): ord('"'),
            ord('\xe2\x80\x9d'.decode('utf-8')): ord('"'),
            ord('\xe2\x80\x9e'.decode('utf-8')): ord('"'),
            ord('\xe2\x80\x9f'.decode('utf-8')): ord('"'),
            ord('\xc3\xa9'.decode('utf-8')): ord('e'),
            ord('\xe2\x80\x9c'.decode('utf-8')): ord('"'),
            ord('\xe2\x80\x93'.decode('utf-8')): ord('-'),
            ord('\xe2\x80\x92'.decode('utf-8')): ord('-'),
            ord('\xe2\x80\x94'.decode('utf-8')): ord('-'),
            ord('\xe2\x80\x94'.decode('utf-8')): ord('-'),
            ord('\xe2\x80\x98'.decode('utf-8')): ord("'"),
            ord('\xe2\x80\x9b'.decode('utf-8')): ord("'"),

            ord('\xe2\x80\x90'.decode('utf-8')): ord('-'),
            ord('\xe2\x80\x91'.decode('utf-8')): ord('-'),

            ord('\xe2\x80\xb2'.decode('utf-8')): ord("'"),
            ord('\xe2\x80\xb3'.decode('utf-8')): ord("'"),
            ord('\xe2\x80\xb4'.decode('utf-8')): ord("'"),
            ord('\xe2\x80\xb5'.decode('utf-8')): ord("'"),
            ord('\xe2\x80\xb6'.decode('utf-8')): ord("'"),
            ord('\xe2\x80\xb7'.decode('utf-8')): ord("'"),

            ord('\xe2\x81\xba'.decode('utf-8')): ord("+"),
            ord('\xe2\x81\xbb'.decode('utf-8')): ord("-"),
            ord('\xe2\x81\xbc'.decode('utf-8')): ord("="),
            ord('\xe2\x81\xbd'.decode('utf-8')): ord("("),
            ord('\xe2\x81\xbe'.decode('utf-8')): ord(")"),

                            }
    return text.decode('utf-8').translate(uni2ascii).encode('ascii')


#clean tweet's html, url)
p.set_options(p.OPT.URL, p.OPT.MENTION, p.OPT.RESERVED)

# add another coloumn with the unedited version of the tweet
html_parser = HTMLParser.HTMLParser()

#outtweets include place,unique id,time, and cleaned text
#cleaned text: for repetitive words, encoding, special charaters
outtweets = [[tweet.place, tweet.id_str, tweet.created_at, p.clean(''.join(''.join(s)[:2] for _, s in itertools.groupby(unicodetoascii(html_parser.unescape(tweet.text.encode("ascii","ignore").decode("utf8")))))), ''.join(''.join(s)[:2] for _, s in itertools.groupby(unicodetoascii(html_parser.unescape(tweet.text.encode("ascii","ignore").decode("utf8"))))) ] for tweet in tweepy.Cursor(api.search, **kwargs).items(300)]
with open('twitterdata_newyork.csv', 'wb') as f:
	writer = csv.writer(f)
	writer.writerow(["place", "id","created_at","text","text unclean"])
	writer.writerows(outtweets)

####unused code
# # myfile = open(, 'w')
# myfile = open('twitterdata.csv', 'w')
# new_list=[]
# for status in tweepy.Cursor(api.search, **kwargs).items(10):
#     print status.text
#     new_list.append(status.text)
# for i in new_list:
#     myfile.write('%s' % i.encode("utf-8"))
# myfile.close()
# with open('twitterdata.txt', 'w') as outfile:
#     json.dump(new_dict, outfile)
# myfile.write("%s \n" % new_dict)
# myfile.close()

# with open('twitterdata.json', 'w') as outfile:
#     tweetdata=[]
#     for status in tweepy.Cursor(api.search, **kwargs).items(10):
#         tweetdata.append(status._json)
#     json.dump(tweetdata, outfile)

